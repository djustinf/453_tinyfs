/* Program 4
 * Daniel Foxhoven
 * Geoff Wacker
 * Adair Camacho 
 * Due Date: 3/19/17
 */

#ifndef TINYFS_H
#define TINYFS_H

#define BLOCKSIZE 256
#define DEFAULT_DISK_SIZE 10240
#define DEFAULT_DISK_NAME "tinyFSDisk"

typedef int fileDescriptor;

#endif
